# NJ Lottery Simulator (Android)

A Kotlin + Jetpack Compose app with three features:

1. **Ball machine simulator** — an animated drum of numbered balls (gravity, blower turbulence, wall bounce). Press "Spin the machine" and it tumbles the balls, then pops out a pick for the selected NJ game. Picks come from `SecureRandom`, the same class of randomness a quick-pick terminal uses.
2. **Supported NJ games** — Pick-3, Pick-4, Jersey Cash 5, Pick-6, Cash4Life, Powerball, Mega Millions (matrices defined in `model/LotteryGame.kt`; update there if NJ changes a game's matrix).
3. **Ticket scanner + checker** — CameraX + ML Kit reads the barcode on a ticket; the checker screen compares your play numbers against official winning numbers and highlights matches.

## Build & run

1. Open the project folder in Android Studio (Koala or newer).
2. Let Gradle sync (requires JDK 17; Android Studio bundles it).
3. Run on a device with a camera (API 26+). The scanner needs a physical device; the simulator and checker work in an emulator.

If Android Studio asks to add the Gradle wrapper, accept (this archive ships build files only, no wrapper binaries).

## Honest limitations — read this

- **There is no such thing as lottery prediction.** Every NJ draw is an independent random event; no pattern, hot/cold analysis, or AI can improve your odds. This app generates picks; it does not and cannot predict.
- **Barcodes cannot reveal win status offline.** The barcode on a NJ draw ticket is an encrypted serial number. It does not contain the play numbers, and only the NJ Lottery's backend (official app, retailer terminal, njlottery.com) can validate it. This app records the scanned serial and checks numbers you type in against winning numbers you obtain from an official source. A `WinningNumbersSource` interface in `ui/check/CheckTicketScreen.kt` is the hook if you ever license an official feed.
- **Always validate any apparent win officially** before discarding a ticket.
- If you publish this, Google Play classifies lottery-related apps under gambling policies — review them, include responsible-gambling messaging (1-800-GAMBLER in NJ), and restrict to 18+.

## Project layout

```
app/src/main/java/com/example/njlottery/
├── MainActivity.kt               # navigation + home screen
├── model/LotteryGame.kt          # NJ game matrices
├── picker/QuickPick.kt           # SecureRandom draw logic
└── ui/
    ├── machine/BallMachineScreen.kt  # animated drum physics
    ├── scanner/ScannerScreen.kt      # CameraX + ML Kit barcode
    ├── check/CheckTicketScreen.kt    # match checker
    └── theme/Theme.kt
```
