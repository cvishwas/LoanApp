package com.example.njlottery.model

/**
 * Definitions of New Jersey draw games.
 *
 * mainCount  : how many main balls are drawn
 * mainMax    : main balls are numbered 1..mainMax (or 0..9 for digit games)
 * bonusMax   : 0 = no bonus ball; otherwise bonus ball is 1..bonusMax
 * digitGame  : true for Pick-3 / Pick-4 style games (digits 0-9, repeats allowed, order matters)
 */
enum class LotteryGame(
    val title: String,
    val mainCount: Int,
    val mainMax: Int,
    val bonusMax: Int = 0,
    val bonusName: String = "",
    val digitGame: Boolean = false,
) {
    PICK_3("Pick-3", mainCount = 3, mainMax = 9, digitGame = true),
    PICK_4("Pick-4", mainCount = 4, mainMax = 9, digitGame = true),
    JERSEY_CASH_5("Jersey Cash 5", mainCount = 5, mainMax = 45),
    PICK_6("Pick-6", mainCount = 6, mainMax = 46),
    CASH4LIFE("Cash4Life", mainCount = 5, mainMax = 60, bonusMax = 4, bonusName = "Cash Ball"),
    POWERBALL("Powerball", mainCount = 5, mainMax = 69, bonusMax = 26, bonusName = "Powerball"),
    MEGA_MILLIONS("Mega Millions", mainCount = 5, mainMax = 70, bonusMax = 24, bonusName = "Mega Ball");

    val ballRange: IntRange
        get() = if (digitGame) 0..9 else 1..mainMax
}

/** One completed draw produced by the simulator. */
data class DrawResult(
    val game: LotteryGame,
    val mainNumbers: List<Int>,
    val bonusNumber: Int? = null,
) {
    fun display(): String = buildString {
        append(mainNumbers.joinToString("  ") { it.toString().padStart(2, '0') })
        bonusNumber?.let { append("   ${game.bonusName}: ${it.toString().padStart(2, '0')}") }
    }
}
