package com.example.njlottery.ui.scanner

import android.Manifest
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage

/**
 * Scans the barcode printed on a NJ Lottery ticket.
 *
 * IMPORTANT HONESTY NOTE: the barcode on a draw-game ticket encodes an
 * encrypted serial number, NOT the playing numbers and NOT the win status.
 * Only the NJ Lottery's own system can validate a ticket from its barcode
 * (that's what the official app and retailer terminals do). This screen
 * captures the barcode so you can keep a record of the ticket, then hands
 * you off to the checker screen to compare numbers manually.
 */
@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun ScannerScreen(onBarcode: (String) -> Unit, onBack: () -> Unit) {
    val cameraPermission = rememberPermissionState(Manifest.permission.CAMERA)
    var lastValue by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("Back") }
            Text("Scan ticket barcode", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        if (!cameraPermission.status.isGranted) {
            Spacer(Modifier.height(24.dp))
            Text("Camera access is needed to scan the barcode on your ticket.")
            Spacer(Modifier.height(12.dp))
            Button(onClick = { cameraPermission.launchPermissionRequest() }) {
                Text("Allow camera")
            }
        } else {
            CameraBarcodePreview(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(vertical = 12.dp),
                onResult = { value -> if (value != lastValue) lastValue = value },
            )
            lastValue?.let { v ->
                Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Barcode found:", fontWeight = FontWeight.SemiBold)
                        Text(v, fontSize = 13.sp)
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { onBarcode(v) }) { Text("Use this ticket") }
                    }
                }
            }
            Text(
                "Ticket barcodes are encrypted serial numbers — only the NJ Lottery " +
                    "can officially validate a ticket. Use the checker screen to compare " +
                    "your numbers against the official winning numbers from njlottery.com.",
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
    }
}

@Composable
private fun CameraBarcodePreview(modifier: Modifier, onResult: (String) -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val scanner = remember {
        BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                    Barcode.FORMAT_CODE_128,
                    Barcode.FORMAT_CODE_39,
                    Barcode.FORMAT_ITF,
                    Barcode.FORMAT_PDF417,
                    Barcode.FORMAT_QR_CODE,
                    Barcode.FORMAT_DATA_MATRIX,
                )
                .build()
        )
    }
    DisposableEffect(Unit) { onDispose { scanner.close() } }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            val previewView = PreviewView(ctx)
            val providerFuture = ProcessCameraProvider.getInstance(ctx)
            providerFuture.addListener({
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(ContextCompat.getMainExecutor(ctx)) { proxy ->
                    processFrame(proxy, scanner, onResult)
                }
                provider.unbindAll()
                provider.bindToLifecycle(
                    lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis,
                )
            }, ContextCompat.getMainExecutor(ctx))
            previewView
        },
    )
}

@androidx.camera.core.ExperimentalGetImage
private fun processFrame(
    proxy: ImageProxy,
    scanner: com.google.mlkit.vision.barcode.BarcodeScanner,
    onResult: (String) -> Unit,
) {
    val mediaImage = proxy.image ?: run { proxy.close(); return }
    val image = InputImage.fromMediaImage(mediaImage, proxy.imageInfo.rotationDegrees)
    scanner.process(image)
        .addOnSuccessListener { barcodes ->
            barcodes.firstOrNull()?.rawValue?.let(onResult)
        }
        .addOnCompleteListener { proxy.close() }
}
