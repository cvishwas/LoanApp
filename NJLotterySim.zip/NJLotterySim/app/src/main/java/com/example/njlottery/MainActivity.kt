package com.example.njlottery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.njlottery.model.LotteryGame
import com.example.njlottery.ui.check.CheckTicketScreen
import com.example.njlottery.ui.machine.BallMachineScreen
import com.example.njlottery.ui.scanner.ScannerScreen
import com.example.njlottery.ui.theme.AppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { AppNav() } }
    }
}

@Composable
fun AppNav() {
    val nav = rememberNavController()
    var lastBarcode by remember { mutableStateOf<String?>(null) }

    NavHost(nav, startDestination = "home") {
        composable("home") {
            HomeScreen(
                onPick = { game -> nav.navigate("machine/${game.name}") },
                onScan = { nav.navigate("scan") },
            )
        }
        composable(
            "machine/{game}",
            arguments = listOf(navArgument("game") { type = NavType.StringType }),
        ) { entry ->
            val game = LotteryGame.valueOf(entry.arguments!!.getString("game")!!)
            BallMachineScreen(game) { nav.popBackStack() }
        }
        composable("scan") {
            ScannerScreen(
                onBarcode = { code ->
                    lastBarcode = code
                    nav.navigate("checkSelect")
                },
                onBack = { nav.popBackStack() },
            )
        }
        composable("checkSelect") {
            GamePickList(title = "Which game is the ticket for?") { game ->
                nav.navigate("check/${game.name}")
            }
        }
        composable(
            "check/{game}",
            arguments = listOf(navArgument("game") { type = NavType.StringType }),
        ) { entry ->
            val game = LotteryGame.valueOf(entry.arguments!!.getString("game")!!)
            CheckTicketScreen(game, lastBarcode) { nav.popBackStack("home", inclusive = false) }
        }
    }
}

@Composable
fun HomeScreen(onPick: (LotteryGame) -> Unit, onScan: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("NJ Lottery Simulator", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(
            "A ball-machine simulator and ticket checker. Picks are pure secure " +
                "randomness — no app can predict lottery numbers, and anyone claiming " +
                "otherwise is selling snake oil. Play responsibly. 18+.",
            fontSize = 12.sp, color = Color.Gray,
            modifier = Modifier.padding(vertical = 8.dp),
        )
        Button(onClick = onScan, modifier = Modifier.fillMaxWidth()) {
            Text("Scan a ticket / check for a win")
        }
        Spacer(Modifier.height(16.dp))
        Text("Spin the machine", fontWeight = FontWeight.SemiBold)
        GamePickList(title = null, onPick = onPick)
    }
}

@Composable
fun GamePickList(title: String?, onPick: (LotteryGame) -> Unit) {
    Column(Modifier.padding(top = 8.dp)) {
        title?.let {
            Text(it, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
        }
        LazyColumn {
            items(LotteryGame.entries) { game ->
                Card(
                    onClick = { onPick(game) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp, horizontal = if (title != null) 16.dp else 0.dp),
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(game.title, fontWeight = FontWeight.SemiBold)
                            Text(
                                if (game.digitGame) "${game.mainCount} digits, 0–9"
                                else buildString {
                                    append("${game.mainCount} of 1–${game.mainMax}")
                                    if (game.bonusMax > 0) append(" + ${game.bonusName} 1–${game.bonusMax}")
                                },
                                fontSize = 12.sp, color = Color.Gray,
                            )
                        }
                        Text("›", fontSize = 22.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}
