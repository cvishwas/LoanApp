package com.example.njlottery.ui.machine

import androidx.compose.animation.core.withInfiniteAnimationFrameNanos
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.njlottery.model.DrawResult
import com.example.njlottery.model.LotteryGame
import com.example.njlottery.picker.QuickPick
import java.security.SecureRandom
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Physics state for one ball tumbling in the drum. */
private class Ball(
    val number: Int,
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val hue: Float,
)

private const val BALL_R = 0.055f          // ball radius, fraction of drum radius
private const val GRAVITY = 1.6f           // downward pull (drum units / s^2)
private const val BLOWER = 5.2f            // upward turbulence strength while mixing
private const val DAMPING = 0.995f

@Composable
fun BallMachineScreen(game: LotteryGame, onBack: () -> Unit) {
    val rng = remember { SecureRandom() }

    // Pre-decide the result with the secure RNG; the animation then "draws"
    // those exact balls so what you watch is what you get.
    var result by remember(game) { mutableStateOf<DrawResult?>(null) }
    var drawnSoFar by remember(game) { mutableStateOf(listOf<Int>()) }
    var bonusShown by remember(game) { mutableStateOf<Int?>(null) }
    var mixing by remember(game) { mutableStateOf(false) }
    var history by remember(game) { mutableStateOf(listOf<DrawResult>()) }

    val balls = remember(game) {
        game.ballRange.map { n ->
            val a = rng.nextFloat() * 6.2832f
            val r = sqrt(rng.nextFloat()) * 0.8f
            Ball(
                number = n,
                x = cos(a) * r, y = sin(a) * r,
                vx = rng.nextFloat() * 2f - 1f,
                vy = rng.nextFloat() * 2f - 1f,
                hue = (n * 47 % 360).toFloat(),
            )
        }.toMutableStateList()
    }

    // Physics loop
    LaunchedEffect(game) {
        var last = 0L
        while (true) {
            withInfiniteAnimationFrameNanos { now ->
                val dt = if (last == 0L) 0.016f else ((now - last) / 1e9f).coerceAtMost(0.033f)
                last = now
                stepPhysics(balls, dt, mixing, rng)
            }
        }
    }

    // Draw sequence: mix, then pop balls out one per second
    LaunchedEffect(result) {
        val res = result ?: return@LaunchedEffect
        mixing = true
        drawnSoFar = emptyList()
        bonusShown = null
        kotlinx.coroutines.delay(2200)            // tumble time
        for (n in res.mainNumbers) {
            drawnSoFar = drawnSoFar + n
            kotlinx.coroutines.delay(900)
        }
        bonusShown = res.bonusNumber
        mixing = false
        history = (listOf(res) + history).take(10)
    }

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("Back") }
            Spacer(Modifier.weight(1f))
            Text(game.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Spacer(Modifier.width(64.dp))
        }

        // The drum
        Canvas(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .padding(8.dp)
        ) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val R = size.minDimension / 2f * 0.96f

            // Glass drum
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(0x22FFFFFF), Color(0x11000000)),
                    center = Offset(cx, cy), radius = R,
                ),
                radius = R, center = Offset(cx, cy),
            )
            drawCircle(Color(0xFF4A5568), radius = R, center = Offset(cx, cy), style = Stroke(8f))

            val drawnSet = drawnSoFar.toSet()
            val textPaint = android.graphics.Paint().apply {
                textAlign = android.graphics.Paint.Align.CENTER
                isAntiAlias = true
                isFakeBoldText = true
                color = android.graphics.Color.BLACK
            }
            balls.forEach { b ->
                if (b.number in drawnSet) return@forEach   // already popped out
                val px = cx + b.x * R
                val py = cy + b.y * R
                val r = BALL_R * R
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color.hsl(b.hue, 0.7f, 0.75f), Color.hsl(b.hue, 0.7f, 0.45f)),
                        center = Offset(px - r * 0.3f, py - r * 0.3f), radius = r * 1.4f,
                    ),
                    radius = r, center = Offset(px, py),
                )
                textPaint.textSize = r
                drawContext.canvas.nativeCanvas.drawText(
                    b.number.toString(), px, py + r * 0.35f, textPaint,
                )
            }
        }

        // Drawn balls tray
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.Center,
        ) {
            drawnSoFar.forEach { DrawnBall(it, Color(0xFF1565C0)) }
            bonusShown?.let {
                Spacer(Modifier.width(12.dp))
                DrawnBall(it, Color(0xFFC62828))
            }
        }
        if (bonusShown != null && game.bonusMax > 0) {
            Text(game.bonusName, fontSize = 12.sp, color = Color.Gray)
        }

        Button(
            enabled = !mixing,
            onClick = { result = QuickPick.draw(game) },
            modifier = Modifier.padding(top = 8.dp),
        ) { Text(if (mixing) "Drawing…" else "Spin the machine") }

        Text(
            "Numbers are generated with a secure RNG, like a quick-pick. " +
                "Every combination is equally likely — nothing can predict a lottery draw.",
            fontSize = 11.sp, color = Color.Gray,
            modifier = Modifier.padding(top = 12.dp),
        )

        if (history.isNotEmpty()) {
            Text("Recent picks", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp))
            LazyRow {
                items(history) { h ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        tonalElevation = 2.dp,
                        modifier = Modifier.padding(4.dp),
                    ) { Text(h.display(), Modifier.padding(8.dp), fontSize = 13.sp) }
                }
            }
        }
    }
}

@Composable
private fun DrawnBall(number: Int, color: Color) {
    Box(
        Modifier
            .padding(horizontal = 3.dp)
            .size(40.dp)
            .background(color, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            number.toString().padStart(2, '0'),
            color = Color.White, fontWeight = FontWeight.Bold,
        )
    }
}

/** Simple drum physics: gravity + blower turbulence + wall bounce + soft ball-ball separation. */
private fun stepPhysics(balls: List<Ball>, dt: Float, mixing: Boolean, rng: SecureRandom) {
    balls.forEach { b ->
        b.vy += GRAVITY * dt
        if (mixing) {
            b.vx += (rng.nextFloat() - 0.5f) * BLOWER * dt * 4f
            b.vy -= rng.nextFloat() * BLOWER * dt * 3.2f
        }
        b.vx *= DAMPING; b.vy *= DAMPING
        b.x += b.vx * dt; b.y += b.vy * dt

        // Bounce off the circular wall
        val limit = 1f - BALL_R
        val d = sqrt(b.x * b.x + b.y * b.y)
        if (d > limit) {
            val nx = b.x / d; val ny = b.y / d
            b.x = nx * limit; b.y = ny * limit
            val dot = b.vx * nx + b.vy * ny
            b.vx -= 1.7f * dot * nx
            b.vy -= 1.7f * dot * ny
        }
    }
    // Cheap pairwise separation so balls don't overlap badly
    for (i in balls.indices) for (j in i + 1 until balls.size) {
        val a = balls[i]; val b = balls[j]
        val dx = b.x - a.x; val dy = b.y - a.y
        val dist = sqrt(dx * dx + dy * dy)
        val min = BALL_R * 2f
        if (dist > 0f && dist < min) {
            val push = (min - dist) / 2f
            val nx = dx / dist; val ny = dy / dist
            a.x -= nx * push; a.y -= ny * push
            b.x += nx * push; b.y += ny * push
        }
    }
}
