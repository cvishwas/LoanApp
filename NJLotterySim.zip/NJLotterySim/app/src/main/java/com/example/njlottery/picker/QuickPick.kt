package com.example.njlottery.picker

import com.example.njlottery.model.DrawResult
import com.example.njlottery.model.LotteryGame
import java.security.SecureRandom

/**
 * Draws numbers exactly the way a quick-pick terminal does: with a
 * cryptographically secure RNG and no weighting whatsoever.
 *
 * Deliberately NOT a "predictor". Every combination is equally likely on
 * every draw; past results carry zero information about future ones.
 */
object QuickPick {

    private val rng = SecureRandom()

    fun draw(game: LotteryGame): DrawResult {
        val main: List<Int> = if (game.digitGame) {
            // Digit games: independent digits 0-9, repeats allowed, order kept.
            List(game.mainCount) { rng.nextInt(10) }
        } else {
            // Ball games: sample without replacement, then sort for display.
            val pool = (1..game.mainMax).toMutableList()
            buildList {
                repeat(game.mainCount) {
                    add(pool.removeAt(rng.nextInt(pool.size)))
                }
            }.sorted()
        }
        val bonus = if (game.bonusMax > 0) rng.nextInt(game.bonusMax) + 1 else null
        return DrawResult(game, main, bonus)
    }
}
