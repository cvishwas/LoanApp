package com.example.njlottery.ui.check

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.njlottery.model.LotteryGame

/**
 * Compares the numbers on your ticket against the official winning numbers.
 *
 * Winning numbers must come from an official source (njlottery.com or a
 * retailer). There is no public NJ Lottery API; if one becomes available,
 * wire it into [WinningNumbersSource] below and the UI picks it up.
 */
@Composable
fun CheckTicketScreen(game: LotteryGame, scannedBarcode: String?, onBack: () -> Unit) {
    var ticketInput by remember { mutableStateOf("") }
    var ticketBonus by remember { mutableStateOf("") }
    var winningInput by remember { mutableStateOf("") }
    var winningBonus by remember { mutableStateOf("") }
    var verdict by remember { mutableStateOf<CheckOutcome?>(null) }

    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("Back") }
            Text("Check a ${game.title} ticket", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        scannedBarcode?.let {
            Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                Column(Modifier.padding(10.dp)) {
                    Text("Scanned ticket serial", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(it, fontSize = 12.sp)
                    Text(
                        "The serial identifies the ticket but does not contain the play " +
                            "numbers — enter them from the face of the ticket below.",
                        fontSize = 11.sp, color = Color.Gray,
                    )
                }
            }
        }

        OutlinedTextField(
            value = ticketInput,
            onValueChange = { ticketInput = it; verdict = null },
            label = { Text("Your numbers (e.g. 5 12 23 31 44)") },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        )
        if (game.bonusMax > 0) OutlinedTextField(
            value = ticketBonus,
            onValueChange = { ticketBonus = it; verdict = null },
            label = { Text("Your ${game.bonusName}") },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        )

        OutlinedTextField(
            value = winningInput,
            onValueChange = { winningInput = it; verdict = null },
            label = { Text("Official winning numbers (from njlottery.com)") },
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
        )
        if (game.bonusMax > 0) OutlinedTextField(
            value = winningBonus,
            onValueChange = { winningBonus = it; verdict = null },
            label = { Text("Winning ${game.bonusName}") },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        )

        Button(
            onClick = {
                verdict = check(
                    game,
                    parse(ticketInput), ticketBonus.trim().toIntOrNull(),
                    parse(winningInput), winningBonus.trim().toIntOrNull(),
                )
            },
            modifier = Modifier.padding(top = 16.dp),
        ) { Text("Check ticket") }

        verdict?.let { v ->
            Spacer(Modifier.height(16.dp))
            when (v) {
                is CheckOutcome.Error -> Text(v.message, color = MaterialTheme.colorScheme.error)
                is CheckOutcome.Result -> ResultCard(game, v)
            }
        }

        Text(
            "Always verify any potential win with the NJ Lottery — at a retailer, " +
                "through the official NJ Lottery app, or at njlottery.com. This app " +
                "compares numbers only and is not an official validation.",
            fontSize = 11.sp, color = Color.Gray,
            modifier = Modifier.padding(top = 20.dp),
        )
    }
}

@Composable
private fun ResultCard(game: LotteryGame, r: CheckOutcome.Result) {
    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(
                if (r.anyMatch) "You matched something!" else "No matches this time.",
                fontWeight = FontWeight.Bold, fontSize = 16.sp,
            )
            Spacer(Modifier.height(8.dp))
            Row {
                r.ticket.forEach { n ->
                    val hit = n in r.matched
                    Box(
                        Modifier.padding(2.dp).size(36.dp)
                            .background(if (hit) Color(0xFF2E7D32) else Color(0xFF9E9E9E), CircleShape),
                        contentAlignment = Alignment.Center,
                    ) { Text(n.toString(), color = Color.White, fontWeight = FontWeight.Bold) }
                }
            }
            Text("Main numbers matched: ${r.matched.size} of ${game.mainCount}")
            if (game.bonusMax > 0) {
                Text(if (r.bonusMatched) "${game.bonusName}: matched ✓" else "${game.bonusName}: not matched")
            }
            Text(
                "Prize tiers vary by draw — check the official prize table for what " +
                    "this match level pays.",
                fontSize = 11.sp, color = Color.Gray,
            )
        }
    }
}

private fun parse(s: String): List<Int> =
    s.split(Regex("[,\\s]+")).mapNotNull { it.trim().toIntOrNull() }

sealed interface CheckOutcome {
    data class Error(val message: String) : CheckOutcome
    data class Result(
        val ticket: List<Int>,
        val matched: Set<Int>,
        val bonusMatched: Boolean,
    ) : CheckOutcome {
        val anyMatch get() = matched.isNotEmpty() || bonusMatched
    }
}

private fun check(
    game: LotteryGame,
    ticket: List<Int>, ticketBonus: Int?,
    winning: List<Int>, winningBonus: Int?,
): CheckOutcome {
    if (ticket.size != game.mainCount)
        return CheckOutcome.Error("Enter exactly ${game.mainCount} numbers for your ticket.")
    if (winning.size != game.mainCount)
        return CheckOutcome.Error("Enter exactly ${game.mainCount} winning numbers.")
    val range = game.ballRange
    if (ticket.any { it !in range } || winning.any { it !in range })
        return CheckOutcome.Error("Numbers for ${game.title} must be in ${range.first}–${range.last}.")
    if (game.bonusMax > 0 && (ticketBonus == null || winningBonus == null))
        return CheckOutcome.Error("Enter both ${game.bonusName} values (1–${game.bonusMax}).")

    val matched: Set<Int> = if (game.digitGame) {
        // Digit games are position-based (straight): compare position by position.
        ticket.filterIndexed { i, d -> winning.getOrNull(i) == d }.toSet()
    } else {
        ticket.toSet() intersect winning.toSet()
    }
    val bonusOk = game.bonusMax > 0 && ticketBonus != null && ticketBonus == winningBonus
    return CheckOutcome.Result(ticket, matched, bonusOk)
}

/**
 * Placeholder for an official winning-numbers feed. The NJ Lottery does not
 * publish a public API; results are posted at https://www.njlottery.com.
 * If you license or build a data feed, implement this and call it from the
 * screen to pre-fill the winning numbers.
 */
interface WinningNumbersSource {
    suspend fun latest(game: LotteryGame): Pair<List<Int>, Int?>?
}
